#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"

int main()
{
    //printf("main started....\n");
    init();
    createLoad();
    releaseMemory();
}
