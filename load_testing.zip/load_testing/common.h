//
// Created by Reshad-Hasan on 23-Jan-20.
//

#ifndef LOAD_TESTING_COMMON_H
#define LOAD_TESTING_COMMON_H

#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>

#include "config.h"

#define SUCCESS 1
#define FAIL 0
#define HOST_SIZE 256

typedef struct
{
    float responseTime;
    char hostName[HOST_SIZE];
}pingResponse;

char hostFile[100];
char responseFile[100];
int threadCount;
char **hostBuffer;

int bufSize=0;
pingResponse *responseBuffer;
int responseBufferSize=0;
int processed=0;

pthread_t *tidArray;

bool pingFlag;

FILE *responseFP;

pthread_mutex_t lock;

/**
 * this function removes whitespaces from front and back
 * @param string
 * @return SUCCESS of FAIL
 */
int Trim(char *string)
{
    char* firstNonSpace = string;
    int len;

    if (string == NULL)
        return FAIL;

    while (*firstNonSpace != '\0' && *firstNonSpace == ' ')
    {
        ++firstNonSpace;
    }

    len = strlen(firstNonSpace) + 1;
    memmove(string, firstNonSpace, len);

    len = strlen(string);
    len = len - 1;
    while (string[len] == ' ' || string[len]=='\n' || string[len]=='\r')
    {
        string[len] = '\0';
        len--;
    }
    return SUCCESS;
}

/**
 * fills host name buffer from host file
 * @param hostFilePointer | host file is open in reading mode in this pointer
 * @return | number of host name inserted in the buffer
 */
int fillBuffer(FILE *hostFilePointer)
{
    //printf("fillBuffer()....\n");
    char _line[HOST_SIZE];

    int _count=0;
    while(fgets(_line, sizeof(_line), hostFilePointer))
    {
        Trim(_line);
        //printf("%s\n",_line);
        memset(hostBuffer[_count],0,HOST_SIZE);
        strncpy(hostBuffer[_count],_line,strlen(_line));
        memset(_line,0,sizeof(_line));
        _count++;
        if(_count==threadCount)
        {
            break;
        }
    }
    //printf("buffer filled\n");
    return _count;
}


/**
 * this function waits until all hostname from the host buffer is pinged
 * and the response time is inserted in response buffer
 * then all response time is saved in response file which is open in a global file pointer
 * @param _bufSize | the number of host names in host buffer
 */
void writeResponseTime(int _bufSize)
{
    //printf("writeResponseTime() started with buffer size = %d\n",_bufSize);
    int i;
    while(responseBufferSize != _bufSize)
    {
        //printf("processing done - %d\n",processed);
        usleep(500);//500 milisecond
    }
    pingFlag=false;
    for(i=0;i<responseBufferSize;i++)
    {
        fprintf(responseFP,"%s %f\n",responseBuffer[i].hostName,responseBuffer[i].responseTime);
    }
    responseBufferSize=0;
    memset(responseBuffer,0,sizeof(responseBuffer));
}

/**
 * this function reads host file and fills the host buffer number of threads at time
 * when buffer is filled ping flag is set to indicate other threads that they can start to ping
 * when all ping is done response time is written
 * until all host name in the host file is processed
 */
void readHostFile()
{
    printf("readHostFile() started...\n");
    FILE *hostFilePointer;

    hostFilePointer=fopen(hostFile,"r");

    if(hostFilePointer==NULL)
    {
        //printf("%s %d\n",hostFile,strlen(hostFile));
        printf("could not open host file\n");
        return;
    }
    while(1)
    {
        bufSize=0;
        bufSize = fillBuffer(hostFilePointer);
        if(bufSize==0)
        {
            printf("empty buffer\n");
            break;
        }
        pingFlag=true;
        writeResponseTime(bufSize);
        processed+=bufSize;
        bufSize=0;
    }

    fclose(hostFilePointer);
}

/**
 * this function runs the ping command with popen function
 * @param _command | this is the ping command with grep and awk for parsing
 * @return | response time of the ping command
 */
float getResponseTime(char* _command)
{
    //printf("ping command =   %s\n",_command);
    FILE *fp;
    char line[100],*value;
    float _responseTime;
    fp=popen(_command,"r");
    fgets(line,sizeof(line),fp);
    strtok_r(line,"=",&value);
    Trim(value);
    _responseTime=strtof(value,NULL);
    //printf("response time = %d\n",_responseTime);
    pclose(fp);
    return _responseTime;
}

/**
 * stores response time and host name in the response time buffer
 * @param _responseTime | response time of ping command
 * @param bufferIndex | index of the host name in host buffer corresponding to the response time
 * mutex lock is needed because all threads will call this funciton
 */
void saveResponseTime(float _responseTime, unsigned int bufferIndex)
{
    //printf("saving respoonse\n");
    pthread_mutex_lock(&lock);

    responseBuffer[responseBufferSize].responseTime=_responseTime;
    strncpy(responseBuffer[responseBufferSize].hostName,hostBuffer[bufferIndex],HOST_SIZE);
    responseBufferSize++;

    pthread_mutex_unlock(&lock);

    //printf("response saving done\n");
}

/**
 * this function searches in the thread ID array for it's own ID
 * @param tid
 * @return | the index where tid matched with the thread ID array
 */
int findBufferIndex(pthread_t tid)
{
    int i;
    for(i=0;i<threadCount;i++)
    {
        if(tid==tidArray[i])
        {
            return i;
        }
    }
    return -1;
}

/**
 * this function is called while the creating of threads for creating load through ping command
 * it runs the ping command with the host name it finds at it's buffer index
 * it is guaranteed that every thread is it's own place in the host buffer to take host name
 * it gets finds the response time of ping command and saves the value
 * @return
 */
void* runPingSaveResponseTime()
{
    pthread_t tid;
    unsigned int _bufferIndex=-1;
    float _responseTime, i;
    char _pingCommand[300];

    tid=pthread_self();

    //printf("thread started... tid = %u\n",tid);

    _bufferIndex=findBufferIndex(tid);

    while(1)
    {
        if(pingFlag==false || strlen(hostBuffer[_bufferIndex])==0)
        {
            usleep(500);
            continue;
        }
        memset(_pingCommand, 0, sizeof(_pingCommand));
        Trim(hostBuffer[_bufferIndex]);
        snprintf(_pingCommand, sizeof(_pingCommand), "ping -c 1 %s|grep time=|awk \'{print $7}\'",
                 hostBuffer[_bufferIndex]);

        _responseTime=getResponseTime(_pingCommand);
        saveResponseTime(_responseTime, _bufferIndex);
        memset(hostBuffer[_bufferIndex], 0, HOST_SIZE);
        //printf("length = %d\n",strlen(hostBuffer[_bufferIndex]));
    }
}

/**
 * this function starts all threads
 * the number of threads to start depends on threadCount found in the configuration file
 */
void startAllThread()
{
    printf("starting all threads....\n");
    int i;

    for(i=0;i<threadCount;i++)
    {
        int ret=pthread_create(&tidArray[i], NULL, runPingSaveResponseTime, NULL);
        if(ret!=0)
        {
            printf("could not open thread\n");
            return ;
        }
    }
}


/**
 * this function kills all threads
 */
void killAllThread()
{
    printf("killing all threads\n");
    int i=0;
    for(i=0;i<threadCount;i++)
    {
        pthread_cancel(tidArray[i]);
    }
}

/**
 * this function starts all threads
 * and starts reading the host file
 * when all host name is processed it kill all threads it started
 */
void createLoad()
{
    printf("createLoad() started...\n");
    startAllThread();
    readHostFile();
    killAllThread();
}

#endif //LOAD_TESTING_COMMON_H
