//
// Created by Reshad-Hasan on 23-Jan-20.
//

#ifndef LOAD_TESTING_CONFIG_H
#define LOAD_TESTING_CONFIG_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "common.h"

#define CONFIG_FILE "load.config"

#define HOST_FILE "HOST_FILE"
#define THREAD_COUNT "THREAD_COUNT"
#define RESPONSE_TIME_FILE "RESPONSE_TIME_FILE"


/**
 * this function stores the values from the configuration file
 * to their appropriate variables
 * @param name
 * @param value
 */
void storeValue(const char *name,const char *value)
{
    Trim(value);
    if(strncmp(name,HOST_FILE,sizeof(HOST_FILE))==0)
    {
        snprintf(hostFile, sizeof(hostFile),value);
    }
    else if(strncmp(name,THREAD_COUNT,sizeof(THREAD_COUNT))==0)
    {
        threadCount=atoi(value);
    }
    else if(strncmp(name,RESPONSE_TIME_FILE,sizeof(RESPONSE_TIME_FILE))==0)
    {
        snprintf(responseFile,sizeof(hostFile),value);
    }
}

/**
 * this function reads the configuration file
 * parses every line and stores all values
 * @return SUCCESS or FAIL
 */
int loadConfig()
{
    printf("loadConfig() started...\n");
    FILE *loadConfigFile;
    char line[HOST_SIZE], *value, *name, *tokenParser;

    loadConfigFile=fopen(CONFIG_FILE,"r");
    if(loadConfigFile==NULL)
    {
        printf("could not open load config file\n");
        return FAIL;
    }

    while(fgets(line,sizeof(line),loadConfigFile))
    {
        tokenParser=line;
        name = strtok_r(tokenParser, "->", &tokenParser);
        value = strtok_r(tokenParser, "->", &tokenParser);

        storeValue(name,value);
        memset(line,0, sizeof(line));
    }
    fclose(loadConfigFile);
    return SUCCESS;
}

/**
 * allocate memory for storing host name
 * host buffer is a double pointer and
 * memory allocation is doen in two steps
 * at first we allocated variable number of char pointers
 * and in second step we allocate each char pointer using for loop
 */
void allocateHostBuffer()
{
    int i=0;
    hostBuffer=NULL;
    hostBuffer=(char**)malloc(threadCount * sizeof(char*));
    for(i=0;i<threadCount;i++)
    {
        hostBuffer[i]=(char*)malloc(HOST_SIZE*sizeof(char));
        memset(hostBuffer[i],0,HOST_SIZE);
        if(hostBuffer[i]==NULL)
        {
            printf("hostBuffer allocation failed\n");
            return;
        }
    }
    if(hostBuffer==NULL)
    {
        printf("hostBuffer allocation failed \n");
    }
}

/**
 * allocate memory for storing response time values
 */
void allocateResponseBuffer()
{
    responseBuffer=NULL;
    responseBuffer=(pingResponse *)malloc(threadCount*sizeof(pingResponse));
    if(responseBuffer==NULL)
    {
        printf("response buffer allocation failed\n");
    }
}

/**
 * allocate memory for storing thread IDs
 */
void allocateTidArray()
{
    tidArray=NULL;
    tidArray=(pthread_t *)malloc(threadCount * sizeof(pthread_t));
    if(tidArray==NULL)
    {
        printf("tidArray allocation failed");
    }
}

/**
 * open file for storing response file in a global file pointer
 */
void openResponseFile()
{
    printf("openResponseFile() started...\n");
    responseFP=fopen(responseFile,"w");
    if(responseFP==NULL)
    {
        printf("could not open response file");
        return;
    }
}


/**
 * this function does
 * load configuration
 * memory allocation
 * thread mutex initialization
 * open response file
 * @return
 */
int init()
{
    printf("init() started....\n");
    if(loadConfig()==FAIL)
    {
        printf("failed to load config file\n");
        return FAIL;
    }
    allocateHostBuffer();
    allocateResponseBuffer();
    allocateTidArray();
    printf("memory allocation complete...\n");
    pingFlag=false;

    pthread_mutex_init(&lock,NULL);
    openResponseFile();

}

/**
 * this function releases all memory allocated at initialization
 * and closes response file
 */
void releaseMemory()
{
    int i;
    for(i=0;i<threadCount;i++)
    {
        free(hostBuffer[i]);
    }
    free(hostBuffer);
    free(responseBuffer);
    free(tidArray);

    fclose(responseFP);
}
#endif //LOAD_TESTING_CONFIG_H
